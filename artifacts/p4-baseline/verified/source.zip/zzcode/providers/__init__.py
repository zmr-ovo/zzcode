"""Native provider adapters."""
