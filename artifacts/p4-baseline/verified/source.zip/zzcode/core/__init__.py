"""Provider-independent message contracts."""
